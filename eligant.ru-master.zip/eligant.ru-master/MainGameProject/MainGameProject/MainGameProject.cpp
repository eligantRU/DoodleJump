#include "stdafx.h"
#include "bases.h"
#include "Plates.cpp"
#include "Doodle.cpp"
#include "Game.cpp"

int main()
{
	startGame();
	return 0;
}